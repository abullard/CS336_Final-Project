# CS336_Final-Project

We wrote the all of the code ourselves except for the following:
	Code for playing audio was copied and adapted from a Three.js example 
	cameraControls.js is the very same provided in the course materials
	Code for skybox was copied and adapted from a Three.js example

Sources:
http://habib.wikidot.com/projected-grid-ocean-shader-full-html-version
https://en.wikibooks.org/wiki/GLSL_Programming/Blender/Reflecting_Surfaces
http://soundbible.com/338-Beach-Waves.html - Sound Clip
http://groovemechanic.net/three.js/examples/textures/waternormals.jpg - water normals
http://www.textures4photoshop.com/tex/thumbs/seamless-transparent-water-ocean-ground-texture-thumb47.jpg - water texture